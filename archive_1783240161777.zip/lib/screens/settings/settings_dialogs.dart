import 'package:flutter/material.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:flex_color_picker/flex_color_picker.dart';
import '../../providers/settings_provider.dart';
import '../../models/subtitle_settings.dart';

void showFontPicker(BuildContext ctx, SettingsProvider s) {
  final fonts = [
    ('Roboto', 'Roboto'),
    ('Cairo', 'Cairo'),
    ('Amiri', 'Amiri'),
    ('Noto Naskh Arabic', 'Noto Naskh'),
    ('Tajawal', 'Tajawal'),
    ('monospace', 'Monospace'),
  ];
  final currentFont = s.subtitleSettings.fontFamily;
  showDialog(
    context: ctx,
    builder: (context) => SimpleDialog(
      title: const Text('اختر الخط'),
      children: fonts.map((f) => RadioListTile<String>(
        title: Text(f.$2),
        value: f.$1,
        groupValue: currentFont,
        onChanged: (v) {
          s.updateSubtitleSettings(s.subtitleSettings.copyWith(fontFamily: v!));
          Navigator.pop(context);
        },
      )).toList(),
    ),
  );
}

void showBoostDialog(BuildContext ctx, SettingsProvider s) {
  showDialog(
    context: ctx,
    builder: (context) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        title: const Text('تضخيم الصوت الافتراضي (%)'),
        content: Slider(
          value: s.defaultAudioBoost,
          min: 50,
          max: 200,
          divisions: 30,
          label: '${s.defaultAudioBoost.round()}%',
          onChanged: (v) {
            s.setDefaultAudioBoost(v);
            setDialogState(() {});
          },
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('موافق'))],
      ),
    ),
  );
}

void showAudioLanguagePicker(BuildContext ctx, SettingsProvider s) {
  final langs = {'ara': 'العربية', 'eng': 'الإنجليزية', 'fra': 'الفرنسية', 'spa': 'الإسبانية'};
  showDialog(
    context: ctx,
    builder: (context) => SimpleDialog(
      title: const Text('اختر لغة الصوت المفضلة'),
      children: langs.entries.map((e) => RadioListTile<String>(
        title: Text(e.value),
        value: e.key,
        groupValue: s.preferredAudioLanguage,
        onChanged: (v) { s.setPreferredAudioLanguage(v!); Navigator.pop(context); },
      )).toList(),
    ),
  );
}

void showEncodingPicker(BuildContext ctx, SettingsProvider s) {
  const encodings = ['UTF-8', 'UTF-16', 'Windows-1256', 'ISO-8859-6'];
  showDialog(
    context: ctx,
    builder: (context) => SimpleDialog(
      title: const Text('اختر ترميز الأحرف'),
      children: encodings.map((enc) => RadioListTile<String>(
        title: Text(enc),
        value: enc,
        groupValue: s.subtitleEncoding,
        onChanged: (v) { s.setSubtitleEncoding(v!); Navigator.pop(context); },
      )).toList(),
    ),
  );
}

void showSubtitleLanguagePicker(BuildContext ctx, SettingsProvider s) {
  final langs = {
    'ara': 'العربية',
    'eng': 'الإنجليزية',
    'fra': 'الفرنسية',
    'spa': 'الإسبانية',
    'deu': 'الألمانية',
    'ita': 'الإيطالية',
  };
  showDialog(
    context: ctx,
    builder: (context) => SimpleDialog(
      title: const Text('اختر لغة الترجمة المفضلة'),
      children: langs.entries.map((e) => RadioListTile<String>(
        title: Text(e.value),
        value: e.key,
        groupValue: s.subtitleSettings.autoLanguage,
        onChanged: (v) {
          s.updateSubtitleSettings(s.subtitleSettings.copyWith(autoLanguage: v!));
          Navigator.pop(context);
        },
      )).toList(),
    ),
  );
}

void showSyncDialog(BuildContext ctx, SettingsProvider s) {
  final controller = TextEditingController(text: s.defaultSubtitleSync.toStringAsFixed(1));
  showDialog(
    context: ctx,
    builder: (context) => AlertDialog(
      title: const Text('المزامنة الافتراضية (ثواني)'),
      content: TextField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
        decoration: const InputDecoration(hintText: 'مثال: -0.5 أو 1.0'),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        ElevatedButton(
          onPressed: () {
            final value = double.tryParse(controller.text);
            if (value != null) s.setDefaultSubtitleSync(value);
            Navigator.pop(context);
          },
          child: const Text('موافق'),
        ),
      ],
    ),
  );
}

void showThemePicker(BuildContext ctx, SettingsProvider s) {
  showBottomPicker<ThemeMode>(
    ctx,
    title: 'اختر المظهر',
    currentValue: s.themeMode,
    items: const [
      (ThemeMode.dark, 'داكن', Symbols.dark_mode_rounded),
      (ThemeMode.light, 'فاتح', Symbols.light_mode_rounded),
      (ThemeMode.system, 'تلقائي', Symbols.brightness_auto_rounded),
    ],
    onSelected: s.setThemeMode,
  );
}

void showSpeedPicker(BuildContext ctx, SettingsProvider s) {
  final cs = Theme.of(ctx).colorScheme;
  showModalBottomSheet(
    context: ctx,
    builder: (_) => Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 12),
          child: Text('سرعة التشغيل', style: TextStyle(color: cs.onSurface, fontWeight: FontWeight.w700, fontSize: 16)),
        ),
        const Divider(height: 1),
        ...[0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0].map((sp) => ListTile(
          title: Text('${sp}x'),
          trailing: s.defaultSpeed == sp ? Icon(Symbols.check_rounded, color: cs.primary) : null,
          onTap: () { s.setDefaultSpeed(sp); Navigator.pop(ctx); },
        )),
      ]),
    ),
  );
}

void showSortPicker(BuildContext ctx, SettingsProvider s) {
  showBottomPicker<String>(
    ctx,
    title: 'ترتيب حسب',
    currentValue: s.sortBy,
    items: const [
      ('date', 'التاريخ', Symbols.calendar_today_rounded),
      ('name', 'الاسم', Symbols.sort_by_alpha_rounded),
      ('size', 'الحجم', Symbols.data_usage_rounded),
      ('duration', 'المدة', Symbols.timer_rounded),
    ],
    onSelected: s.setSortBy,
  );
}

void showSeekSecondsPicker(BuildContext ctx, SettingsProvider s) {
  showBottomPicker<int>(
    ctx,
    title: 'مدة القفز عند النقر المزدوج',
    currentValue: s.doubleTapSeekSeconds,
    items: const [
      (5, '5 ثوانٍ', Symbols.fast_rewind_rounded),
      (10, '10 ثوانٍ', Symbols.fast_rewind_rounded),
      (15, '15 ثانية', Symbols.fast_rewind_rounded),
      (30, '30 ثانية', Symbols.fast_rewind_rounded),
    ],
    onSelected: s.setDoubleTapSeekSeconds,
  );
}

void showHideDelayPicker(BuildContext ctx, SettingsProvider s) {
  showBottomPicker<int>(
    ctx,
    title: 'مدة اختفاء أزرار التحكم',
    currentValue: s.controlsHideSeconds,
    items: const [
      (2, '2 ثانية', Symbols.timer_rounded),
      (4, '4 ثوانٍ', Symbols.timer_rounded),
      (6, '6 ثوانٍ', Symbols.timer_rounded),
      (10, '10 ثوانٍ', Symbols.timer_rounded),
    ],
    onSelected: s.setControlsHideSeconds,
  );
}

void showLongPressSpeedDialog(BuildContext ctx, SettingsProvider s) {
  showDialog(
    context: ctx,
    builder: (context) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        title: const Text('سرعة الضغط المطول'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${s.longPressSpeedValue.toStringAsFixed(2)}x'),
            Slider(
              value: s.longPressSpeedValue,
              min: 1.5,
              max: 4.0,
              divisions: 10,
              label: '${s.longPressSpeedValue.toStringAsFixed(2)}x',
              onChanged: (v) {
                s.setLongPressSpeedValue(v);
                setDialogState(() {});
              },
            ),
          ],
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('موافق'))],
      ),
    ),
  );
}

void showGestureSensitivityDialog(BuildContext ctx, SettingsProvider s) {
  showDialog(
    context: ctx,
    builder: (context) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        title: const Text('حساسية الإيماءات'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${(s.gestureSensitivity * 100).round()}%'),
            Slider(
              value: s.gestureSensitivity,
              min: 0.5,
              max: 2.0,
              divisions: 15,
              label: '${(s.gestureSensitivity * 100).round()}%',
              onChanged: (v) {
                s.setGestureSensitivity(v);
                setDialogState(() {});
              },
            ),
          ],
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('موافق'))],
      ),
    ),
  );
}

void showThemeColorPicker(BuildContext ctx, SettingsProvider s) async {
  final picked = await showColorPickerDialog(ctx, s.themeSeedColor);
  s.setThemeSeedColor(picked);
}

void showBottomPicker<T>(
  BuildContext ctx, {
  required String title,
  required List<(T, String, IconData)> items,
  required T currentValue,
  required void Function(T) onSelected,
}) {
  final cs = Theme.of(ctx).colorScheme;
  showModalBottomSheet(
    context: ctx,
    builder: (_) => Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 12),
          child: Text(title, style: TextStyle(color: cs.onSurface, fontWeight: FontWeight.w700, fontSize: 16)),
        ),
        const Divider(height: 1),
        ...items.map((item) => ListTile(
          leading: Icon(item.$3),
          title: Text(item.$2),
          trailing: currentValue == item.$1 ? Icon(Symbols.check_rounded, color: cs.primary) : null,
          onTap: () { onSelected(item.$1); Navigator.pop(ctx); },
        )),
      ]),
    ),
  );
}