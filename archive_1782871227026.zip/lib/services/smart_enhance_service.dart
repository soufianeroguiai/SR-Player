import 'package:media_kit/media_kit.dart';
import 'package:media_kit/src/player/native/player/real.dart';
import 'hdr_service.dart';
import 'scaler_service.dart';

class SmartEnhanceService {
  SmartEnhanceService._();

  static bool _enabled = false;
  static bool get isEnabled => _enabled;

  // ✅ ننتظر حتى يصبح vo نشطاً قبل تطبيق الإعدادات
  static Future<bool> _waitForVO(NativePlayer native,
      {int maxAttempts = 20}) async {
    for (int i = 0; i < maxAttempts; i++) {
      try {
        final vo = (await native.getProperty('current-vo')).trim();
        if (vo.isNotEmpty) return true;
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 150));
    }
    return false;
  }

  static Future<Map<String, String>> _readProperties(NativePlayer native) async {
    final map = <String, String>{};
    Future<void> read(String key) async {
      try { map[key] = (await native.getProperty(key)).trim(); }
      catch (_) { map[key] = ''; }
    }
    await Future.wait([
      read('video-codec'),
      read('video-params/pixelformat'),
      read('video-params/w'),
      read('video-params/h'),
      read('container-fps'),
      read('video-params/gamma'),
      read('video-params/light'),
      read('video-params/primaries'),
      read('hwdec-current'),
    ]);
    return map;
  }

  static Future<void> enable(Player player) async {
    if (_enabled) return;
    final native = player.platform as NativePlayer;

    // ✅ الخطوة الأساسية — ننتظر vo قبل أي شيء
    final voReady = await _waitForVO(native);
    if (!voReady) return; // الجهاز لا يدعم GPU rendering

    final props = await _readProperties(native);

    final codec      = props['video-codec'] ?? '';
    final pixel      = props['video-params/pixelformat'] ?? '';
    final w          = int.tryParse(props['video-params/w'] ?? '') ?? 0;
    final h          = int.tryParse(props['video-params/h'] ?? '') ?? 0;
    final fps        = double.tryParse(props['container-fps'] ?? '') ?? 0;
    final trc        = props['video-params/gamma'] ?? '';
    final primaries  = props['video-params/primaries'] ?? '';
    final hwCurrent  = props['hwdec-current'] ?? '';

    final maxSide = w > h ? w : h;
    final is10bit = pixel.contains('p10') || pixel.contains('10');
    final isHEVC  = codec.contains('hevc');
    final isHDR   = (trc.contains('pq') || trc.contains('hlg')) &&
                    !primaries.contains('709');

    // ─── 1. التكبير الذكي (يعمل دائماً مع GPU) ──────────────
    await ScalerService.applyBalanced(player);

    // ─── 2. sigmoid + correct downscaling (تحسين حدة الصورة) ─
    await native.setProperty('sigmoid-upscaling', 'yes');
    await native.setProperty('correct-downscaling', 'yes');
    await native.setProperty('linear-downscaling', 'yes');

    // ─── 3. تحسينات حسب نوع الفيديو ─────────────────────────
    if (isHDR) {
      await native.setProperty('contrast', '5');
      await native.setProperty('saturation', '10');
      await native.setProperty('deband', 'yes');
      await HDRService.enable(player);

    } else if (is10bit && isHEVC && maxSide >= 1080) {
      // ✅ أنمي 1080p HEVC 10-bit — أقوى وضع
      await native.setProperty('contrast', '28');
      await native.setProperty('brightness', '-8');
      await native.setProperty('saturation', '35');
      await native.setProperty('gamma', '14');

      // ✅ إجبار RGB Full Range بعد vo نشط
      await native.setProperty('target-prim', 'bt.709');
      await native.setProperty('target-trc', 'srgb');
      await native.setProperty('video-output-levels', 'full');

      await native.setProperty('deband', 'yes');
      await native.setProperty('deband-iterations', '3');
      await native.setProperty('deband-threshold', '60');
      await native.setProperty('deband-range', '16');
      await native.setProperty('deband-grain', '5');

      await native.command([
        'vf', 'add', '@smart:unsharp=luma_msize_x=5:luma_msize_y=5:luma_amount=0.85'
      ]);

    } else if (maxSide <= 640) {
      // دقة منخفضة — شحذ أقوى
      await native.setProperty('contrast', '30');
      await native.setProperty('saturation', '35');
      await native.command([
        'vf', 'add', '@smart:unsharp=luma_msize_x=5:luma_msize_y=5:luma_amount=1.0'
      ]);

    } else {
      // 1080p SDR عام
      await native.setProperty('contrast', '18');
      await native.setProperty('saturation', '20');
      await native.setProperty('deband', 'yes');
      await native.command([
        'vf', 'add', '@smart:unsharp=luma_msize_x=3:luma_msize_y=3:luma_amount=0.45'
      ]);
    }

    // ─── 4. dithering (يقلل تدرجات الألوان الصناعية) ─────────
    await native.setProperty('temporal-dither', 'yes');
    await native.setProperty('dither', 'ordered');

    // ─── 5. تسلسل الإطارات السلس ─────────────────────────────
    if (fps > 0 && fps < 25) {
      await native.setProperty('interpolation', 'yes');
      await native.setProperty('tscale', 'oversample');
    }

    _enabled = true;
  }

  static Future<void> disable(Player player) async {
    if (!_enabled) return;
    final native = player.platform as NativePlayer;

    await HDRService.disable(player);
    await ScalerService.reset(player);
    await native.command(['vf', 'del', '@smart']);

    await native.setProperty('contrast', '0');
    await native.setProperty('brightness', '0');
    await native.setProperty('saturation', '0');
    await native.setProperty('gamma', '0');

    await native.setProperty('deband', 'no');
    await native.setProperty('deband-iterations', '1');
    await native.setProperty('deband-threshold', '32');
    await native.setProperty('deband-range', '16');
    await native.setProperty('deband-grain', '0');

    await native.setProperty('temporal-dither', 'no');
    await native.setProperty('dither', 'fruit');

    await native.setProperty('sigmoid-upscaling', 'no');
    await native.setProperty('correct-downscaling', 'no');
    await native.setProperty('linear-downscaling', 'no');

    await native.setProperty('target-prim', 'auto');
    await native.setProperty('target-trc', 'auto');
    await native.setProperty('video-output-levels', 'auto');

    _enabled = false;
  }

  static Future<void> toggle(Player player) async {
    if (_enabled) await disable(player); else await enable(player);
  }

  // ✅ إعادة تصفير الحالة الداخلية فقط (بدون تعديل الـ player)
  // مفيد بعد video-reload حيث يُعاد تهيئة الـ vo
  static void reset() {
    _enabled = false;
  }
}
