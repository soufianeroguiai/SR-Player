import 'package:flutter/material.dart';

class ColorAdjustmentPanel extends StatelessWidget {
  final double brightness, contrast, saturation, hue, gamma;
  final Function(String type, double value) onChanged;
  final VoidCallback onReset;
  final VoidCallback onClose;

  const ColorAdjustmentPanel({
    super.key,
    required this.brightness,
    required this.contrast,
    required this.saturation,
    required this.hue,
    required this.gamma,
    required this.onChanged,
    required this.onReset,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: GestureDetector(
        onTap: () {},
        onVerticalDragStart: (_) {},
        onVerticalDragUpdate: (_) {},
        onHorizontalDragStart: (_) {},
        onHorizontalDragUpdate: (_) {},
        child: Material(
          color: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.85),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: cs.primary.withOpacity(0.5), width: 1),
              boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 12, spreadRadius: 2)],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white70, size: 20),
                      onPressed: onClose,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                    const Text('تنسيق الألوان', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
                    IconButton(
                      icon: const Icon(Icons.refresh, color: Colors.white70, size: 20),
                      onPressed: onReset,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _CompactHorizontalSlider('السطوع', brightness, cs.primary, (v) => onChanged('brightness', v)),
                _CompactHorizontalSlider('التباين', contrast, cs.primary, (v) => onChanged('contrast', v)),
                _CompactHorizontalSlider('التشبع', saturation, cs.primary, (v) => onChanged('saturation', v)),
                _CompactHorizontalSlider('درجة اللون', hue, cs.primary, (v) => onChanged('hue', v)),
                _CompactHorizontalSlider('Gamma', gamma, cs.primary, (v) => onChanged('gamma', v)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CompactHorizontalSlider extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  final ValueChanged<double> onChanged;

  const _CompactHorizontalSlider(this.label, this.value, this.color, this.onChanged);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6.0),
      child: Row(
        children: [
          SizedBox(
            width: 70,
            child: Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
          ),
          Expanded(
            child: SliderTheme(
              data: SliderThemeData(
                trackHeight: 3,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
                activeTrackColor: color,
                inactiveTrackColor: Colors.white24,
                thumbColor: color,
              ),
              child: Slider(
                value: value.clamp(-100, 100),
                min: -100,
                max: 100,
                onChanged: onChanged,
              ),
            ),
          ),
          SizedBox(
            width: 30,
            child: Text('${value.toInt()}', style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold), textAlign: TextAlign.left),
          ),
        ],
      ),
    );
  }
}