package com.sr.player

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.util.Rational
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val pipChannelName = "com.splayer.app/pip"
    private var pipChannel: MethodChannel? = null

    // يعكس ما إذا كان هناك فيديو قيد التشغيل حالياً فـ Flutter، يُحدَّث
    // باستمرار من Dart عبر setPipEligible فكل مرة تتغيّر فيها حالة
    // التشغيل. نحتاجه هنا محلياً لأن onUserLeaveHint() يُستدعى من طرف
    // أندرويد مباشرة (بدون أي تأخير) ولا يقدر ينتظر رد Async قادم من Dart
    // فتلك اللحظة بالذات.
    private var pipEligible = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, pipChannelName)
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "enterPip" -> {
                    result.success(enterPipMode())
                }
                "setPipEligible" -> {
                    pipEligible = call.arguments as? Boolean ?: false
                    result.success(null)
                }
                "startPlaybackService" -> {
                    val title = call.arguments as? String ?: "SR Player"
                    startPlaybackService(title)
                    result.success(null)
                }
                "stopPlaybackService" -> {
                    stopPlaybackService()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
        pipChannel = channel
    }

    // نبدأ الخدمة الأمامية حتى يبقى الصوت شغّالاً بعد قفل الشاشة (أندرويد
    // يوقف العمليات فالخلفية بدون خدمة أمامية بعد مدة قصيرة من القفل).
    private fun startPlaybackService(title: String) {
        val intent = Intent(this, PlaybackService::class.java).apply {
            putExtra(PlaybackService.EXTRA_TITLE, title)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopPlaybackService() {
        val intent = Intent(this, PlaybackService::class.java).apply {
            action = PlaybackService.ACTION_STOP
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun enterPipMode(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            return enterPictureInPictureMode(params)
        }
        return false
    }

    // هذه هي اللحظة الصحيحة لطلب الدخول لـ PiP على أندرويد: تُستدعى فوراً
    // ولحظة خروج المستخدم من التطبيق (زر الرئيسية، التبديل بين التطبيقات،
    // إيماءة الرجوع...) - قبل أي إيقاف مؤقت فعلي للنشاط (onPause). سابقاً
    // كان الاعتماد فقط على إشعار متأخر قادم من Flutter بعد اكتشاف
    // AppLifecycleState.paused، وهو ما يصل غالباً بعد أن يكون أندرويد قد
    // بدأ الانتقال للخلفية فعلاً، فيرفض طلب الدخول لـ PiP أو يتجاهله.
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (pipEligible) {
            enterPipMode()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pipChannel?.invokeMethod("onPipModeChanged", isInPictureInPictureMode)
    }
}